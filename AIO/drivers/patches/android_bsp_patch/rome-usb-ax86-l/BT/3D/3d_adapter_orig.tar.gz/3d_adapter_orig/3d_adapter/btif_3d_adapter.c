/************************************************************************************
 *
 *  Filename:      bt_3d_adapter.c
 *
 *  Description:   3D Sync Profile Bluetooth Interface
 *
 *
 ***********************************************************************************/
#include <hardware/bluetooth.h>
#include <hardware/bt_3d.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

#define LOG_TAG "BT_3D_ADAPTER"

#include "btif_common.h"
#include "btif_util.h"



bt3d_callbacks_t * d_callbacks = NULL;



/************************************************************************************
**  Static variables
************************************************************************************/

static bt_status_t init(bt3d_callbacks_t *callbacks)
{
    BTIF_TRACE_EVENT("BT_3D_CALL_IN: %s", __FUNCTION__);
    d_callbacks = callbacks;
    return BT_STATUS_SUCCESS;
}

static bt_status_t set_mode(bt3d_mode_t mode, bt_bdaddr_t *master_bd_addr)
{
    bt_status_t status;

    BTIF_TRACE_EVENT("BT_3D_CALL_IN: %s,%d", __FUNCTION__,mode);

    return status;
}

//XXX Reject if we aren't broadcasting?
static bt_status_t broadcast_3d_data(bt3d_data_t data)
{
    BTIF_TRACE_EVENT("BT_3D_CALL_IN: %s", __FUNCTION__);
    BTIF_TRACE_EVENT("BT_3D %d,%d,%d,%d",data.left_open_offset,data.left_close_offset,data.right_open_offset,data.right_close_offset);
    BTIF_TRACE_EVENT("DUAL_VIEW: %d", data.dual_view);
    
    return BT_STATUS_SUCCESS;
}

static void cleanup(void)
{
    BTIF_TRACE_EVENT("BT_3D_CALL_IN: %s", __FUNCTION__);
}


static const bt3d_interface_t bt3dInterface = 
{
    sizeof(bt3d_interface_t),
    init,
    set_mode,
    broadcast_3d_data,
    cleanup,
};

/*******************************************************************************
**
** Function         btif_3d_get_interface
**
** Description      Get the 3d callback interface
**
** Returns          bt3d_interface_t
**
*******************************************************************************/
const bt3d_interface_t *btif_3d_get_interface()
{
    BTIF_TRACE_EVENT("%s", __FUNCTION__);
    return &bt3dInterface;
}

